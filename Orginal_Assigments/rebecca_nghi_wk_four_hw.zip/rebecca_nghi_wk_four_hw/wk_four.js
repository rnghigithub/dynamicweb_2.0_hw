var slideIndex = 1;
showDivs(slideIndex);

function change(m){
    showDivs(slideIndex +=m);
}

function showDivs(m){
    var i;
    var x =  document.getElementsByClassName("img");
    if (m > x.length) {slideIndex = 1}
    if (m < 1) {slideIndex = x.length}  
    for (i = 0; i < x.length; i++) {
        x[i].style.display = "none";
      }
      x[slideIndex-1].style.display = "block";
}


